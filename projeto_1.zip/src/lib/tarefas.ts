/**
 * Registro simples de tarefas longas em andamento.
 *
 * A importação em base nova é acompanhada pela própria tabela base_versao,
 * que sobrevive a reinício. Já o acréscimo de arquivos a uma base existente
 * não muda o status dela (continua ATIVA), então precisa de outro lugar para
 * dizer "ainda estou trabalhando". Como é uma instância só, um mapa em
 * memória basta; se o servidor reiniciar, a transação cai sozinha e a base
 * fica intacta — que é a garantia que importa.
 */
export type EstadoTarefa = 'RODANDO' | 'OK' | 'ERRO';

export interface Tarefa {
  estado: EstadoTarefa;
  iniciadaEm: number;
  erro?: string;
  resultado?: unknown;
}

declare global {
  // eslint-disable-next-line no-var
  var __viabilidadeTarefas: Map<string, Tarefa> | undefined;
}

function mapa(): Map<string, Tarefa> {
  if (!global.__viabilidadeTarefas) global.__viabilidadeTarefas = new Map();
  return global.__viabilidadeTarefas;
}

export function abrirTarefa(id: string): void {
  mapa().set(id, { estado: 'RODANDO', iniciadaEm: Date.now() });
  limpar();
}

export function concluirTarefa(id: string, resultado: unknown): void {
  mapa().set(id, { estado: 'OK', iniciadaEm: Date.now(), resultado });
}

export function falharTarefa(id: string, erro: string): void {
  mapa().set(id, { estado: 'ERRO', iniciadaEm: Date.now(), erro });
}

export function verTarefa(id: string): Tarefa | null {
  return mapa().get(id) ?? null;
}

/** Descarta tarefas terminadas há mais de duas horas. */
function limpar(): void {
  const agora = Date.now();
  for (const [k, v] of mapa()) {
    if (v.estado !== 'RODANDO' && agora - v.iniciadaEm > 2 * 60 * 60_000) {
      mapa().delete(k);
    }
  }
}
