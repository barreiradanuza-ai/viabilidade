'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

interface RelatorioArquivo {
  arquivo: string;
  parceiro: string;
  encoding: string;
  delimitador: string;
  lidos: number;
  validos: number;
  invalidos: number;
  colunasIgnoradas: string[];
  layout: string;
}

interface Adicao {
  baseId: number;
  lidosAgora: number;
  validosAgora: number;
  invalidosAgora: number;
  totalDaBase: number;
  municipios: number;
  arquivos: RelatorioArquivo[];
  porStatus: Array<{ status: string; rotulo: string; qtd: number }>;
}

interface Relatorio {
  arquivos?: RelatorioArquivo[];
  enderecosMultiLote?: number;
  semNumero?: number;
  porStatus?: Array<{ status: string; rotulo: string; qtd: number }>;
  problemas?: Array<{ arquivo: string; linha: number; motivo: string }>;
}

interface Resultado {
  baseId: number;
  lidos: number;
  validos: number;
  invalidos: number;
  duplicados: number;
  enderecosMultiLote: number;
  semNumero: number;
  municipios: number;
  dtRef: string | null;
  arquivos: RelatorioArquivo[];
  porStatus: Array<{ status: string; rotulo: string; qtd: number }>;
  problemas: Array<{ arquivo: string; linha: number; motivo: string }>;
}

const ETAPAS = [
  'Envio dos arquivos',
  'Validação dos cabeçalhos',
  'Processamento',
  'Importação',
  'Indexação',
  'Teste de integridade',
  'Pronta para ativação',
];

const n = (x: number) => x.toLocaleString('pt-BR');

export interface BaseAtiva {
  id: number;
  registros: number;
  arquivos: string[];
}

export default function ImportarBase({ baseAtiva }: { baseAtiva: BaseAtiva | null }) {
  const router = useRouter();
  const [arquivos, setArquivos] = useState<File[]>([]);
  const [destino, setDestino] = useState<'nova' | 'acrescentar'>(
    baseAtiva ? 'acrescentar' : 'nova',
  );
  const [adicionado, setAdicionado] = useState<Adicao | null>(null);
  const [enviando, setEnviando] = useState(false);
  const [progresso, setProgresso] = useState(0);
  const [atual, setAtual] = useState('');
  const [etapa, setEtapa] = useState(-1);
  const [erro, setErro] = useState<string | null>(null);
  const [resultado, setResultado] = useState<Resultado | null>(null);
  const [ativando, setAtivando] = useState(false);
  const [emAndamento, setEmAndamento] = useState(false);

  const totalBytes = arquivos.reduce((s, a) => s + a.size, 0);

  /** Envia um arquivo por vez, com progresso real de upload. */
  function enviarArquivo(sessao: string, f: File, base: number, total: number) {
    return new Promise<void>((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open(
        'POST',
        `/api/admin/import?acao=upload&sessao=${sessao}&nome=${encodeURIComponent(f.name)}`,
      );
      xhr.setRequestHeader('Content-Type', 'application/octet-stream');
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) {
          setProgresso(Math.round(((base + e.loaded) / total) * 100));
        }
      };
      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) return resolve();
        try {
          reject(new Error((JSON.parse(xhr.responseText) as { erro?: string }).erro));
        } catch {
          reject(new Error(`Falha ao enviar ${f.name}.`));
        }
      };
      xhr.onerror = () => reject(new Error(`Falha de rede ao enviar ${f.name}.`));
      xhr.send(f);
    });
  }

  async function enviar() {
    if (!arquivos.length) return;
    setEnviando(true);
    setErro(null);
    setResultado(null);
    setEtapa(0);
    setProgresso(0);

    const sessao = crypto.randomUUID();
    try {
      let enviados = 0;
      for (const f of arquivos) {
        setAtual(f.name);
        await enviarArquivo(sessao, f, enviados, totalBytes);
        enviados += f.size;
      }

      setAtual('');
      setEtapa(1);

      const alvo =
        destino === 'acrescentar' && baseAtiva ? String(baseAtiva.id) : 'nova';
      const r = await fetch(
        `/api/admin/import?acao=processar&sessao=${sessao}&destino=${alvo}`,
        { method: 'POST' },
      );
      const d = (await r.json()) as {
        resultado?: Resultado; erro?: string; aviso?: string;
        emAndamento?: boolean; baseId?: number; tarefaId?: string;
      };

      if (!r.ok) {
        setEtapa(-1);
        setErro(`${d.erro ?? 'Falha na importação.'} ${d.aviso ?? ''}`.trim());
        return;
      }

      // Importação rápida: já veio pronta.
      if (d.resultado) {
        setEtapa(ETAPAS.length - 1);
        setResultado(d.resultado);
        return;
      }

      // Acréscimo a uma base existente: acompanha pela tarefa.
      if (d.tarefaId) {
        setEtapa(2);
        await acompanharTarefa(d.tarefaId);
        return;
      }

      // Importação grande: segue no servidor. A tela acompanha perguntando
      // o status, em vez de ficar segurando a requisição — que é o que
      // fazia o roteador da hospedagem cortar com "upstream error".
      if (d.emAndamento && d.baseId) {
        setEtapa(2);
        await acompanhar(d.baseId);
      }
    } catch (e) {
      setEtapa(-1);
      setErro(e instanceof Error ? e.message : 'Falha no envio.');
    } finally {
      setEnviando(false);
    }
  }

  /** Acompanha o acréscimo de arquivos a uma base existente. */
  async function acompanharTarefa(tarefaId: string) {
    setEmAndamento(true);
    try {
      for (;;) {
        await new Promise((r) => setTimeout(r, 5000));
        const r = await fetch(`/api/admin/import?acao=status&tarefaId=${tarefaId}`, {
          method: 'POST',
          cache: 'no-store',
        }).catch(() => null);
        if (!r || !r.ok) continue;

        const d = (await r.json()) as {
          estado?: string; erro?: string; resultado?: Adicao;
        };
        if (d.estado === 'RODANDO') continue;

        if (d.estado === 'ERRO') {
          setEtapa(-1);
          setErro(`${d.erro ?? 'Falha ao acrescentar.'} A base não foi alterada.`);
          return;
        }

        setEtapa(ETAPAS.length - 1);
        setAdicionado(d.resultado ?? null);
        router.refresh();
        return;
      }
    } finally {
      setEmAndamento(false);
    }
  }

  /** Pergunta o status a cada 5s até a importação terminar. */
  async function acompanhar(baseId: number) {
    setEmAndamento(true);
    try {
      for (;;) {
        await new Promise((r) => setTimeout(r, 5000));
        const r = await fetch(`/api/admin/import?acao=status&baseId=${baseId}`, {
          method: 'POST',
          cache: 'no-store',
        }).catch(() => null);
        if (!r || !r.ok) continue; // falha de rede não cancela nada no servidor

        const d = (await r.json()) as {
          status?: string; erro_mensagem?: string | null;
          registros_validos?: string; registros_invalidos?: string;
          registros_duplicados?: string; registros_lidos?: string;
          dt_ref?: string | null; relatorio?: Relatorio | null;
        };

        if (d.status === 'PROCESSANDO') continue;

        if (d.status === 'ERRO') {
          setEtapa(-1);
          setErro(
            `${d.erro_mensagem ?? 'Falha na importação.'} A base anterior continua ativa.`,
          );
          return;
        }

        // PROCESSADA
        const rel = d.relatorio ?? null;
        setEtapa(ETAPAS.length - 1);
        setResultado({
          baseId,
          lidos: Number(d.registros_lidos ?? 0),
          validos: Number(d.registros_validos ?? 0),
          invalidos: Number(d.registros_invalidos ?? 0),
          duplicados: Number(d.registros_duplicados ?? 0),
          enderecosMultiLote: rel?.enderecosMultiLote ?? 0,
          semNumero: rel?.semNumero ?? 0,
          municipios: 0,
          dtRef: d.dt_ref ?? null,
          arquivos: rel?.arquivos ?? [],
          porStatus: rel?.porStatus ?? [],
          problemas: rel?.problemas ?? [],
        });
        return;
      }
    } finally {
      setEmAndamento(false);
    }
  }

  async function ativar() {
    if (!resultado) return;
    setAtivando(true);
    try {
      const r = await fetch('/api/admin/bases', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ acao: 'ativar', baseId: resultado.baseId }),
      });
      const d = (await r.json()) as { erro?: string };
      if (!r.ok) setErro(d.erro ?? 'Não foi possível ativar.');
      else router.push('/admin/tim');
    } finally {
      setAtivando(false);
    }
  }

  return (
    <>
      <div className="card">
        {baseAtiva && (
          <fieldset
            style={{
              border: '1px solid var(--borda)', borderRadius: 10,
              padding: '14px 16px', margin: '0 0 18px',
            }}
          >
            <legend style={{ fontSize: 13, fontWeight: 600, color: 'var(--texto-2)', padding: '0 6px' }}>
              Para onde vão estes arquivos
            </legend>

            <label style={{ display: 'flex', gap: 9, alignItems: 'flex-start', marginBottom: 10, cursor: 'pointer' }}>
              <input
                type="radio" name="destino" checked={destino === 'acrescentar'}
                disabled={enviando}
                onChange={() => setDestino('acrescentar')}
                style={{ marginTop: 4 }}
              />
              <span>
                <strong>Acrescentar à base que está no ar</strong> (#{baseAtiva.id})
                <div style={{ fontSize: 13, color: 'var(--texto-2)', marginTop: 2 }}>
                  Soma os registros aos {baseAtiva.registros.toLocaleString('pt-BR')} que
                  já existem. É o que você quer quando a entrega vem em muitos
                  arquivos e não dá para mandar todos de uma vez.
                  {baseAtiva.arquivos.length > 0 && (
                    <div style={{ marginTop: 4, color: 'var(--texto-3)', fontSize: 12.5 }}>
                      Já estão nela: {baseAtiva.arquivos.length} arquivo(s).
                    </div>
                  )}
                </div>
              </span>
            </label>

            <label style={{ display: 'flex', gap: 9, alignItems: 'flex-start', cursor: 'pointer' }}>
              <input
                type="radio" name="destino" checked={destino === 'nova'}
                disabled={enviando}
                onChange={() => setDestino('nova')}
                style={{ marginTop: 4 }}
              />
              <span>
                <strong>Criar uma base nova</strong>
                <div style={{ fontSize: 13, color: 'var(--texto-2)', marginTop: 2 }}>
                  Começa do zero. A base atual continua no ar até você ativar a nova.
                  Use quando a TIM mandar a entrega completa de novo.
                </div>
              </span>
            </label>
          </fieldset>
        )}

        <div className="campo">
          <label htmlFor="arq">Arquivos CSV da base</label>
          <input
            id="arq"
            type="file"
            accept=".csv,text/csv,text/plain"
            multiple
            disabled={enviando}
            onChange={(e) => {
              // Acumula em vez de substituir: dá para escolher em várias
              // rodadas, que é como a maioria dos navegadores obriga quando
              // os arquivos estão em pastas diferentes.
              const novos = Array.from(e.target.files ?? []);
              setArquivos((atuais) => {
                const chave = (f: File) => `${f.name}:${f.size}`;
                const vistos = new Set(atuais.map(chave));
                return [...atuais, ...novos.filter((f) => !vistos.has(chave(f)))];
              });
              e.target.value = '';
              setResultado(null);
              setAdicionado(null);
              setErro(null);
              setEtapa(-1);
            }}
          />
        </div>
        <p style={{ fontSize: 13, color: 'var(--texto-3)', margin: '8px 0 0' }}>
          Selecione todos os arquivos de uma vez — a TIM entrega um CSV por
          parceiro/estado e juntos eles formam <strong>uma</strong> base.
        </p>

        {arquivos.length > 0 && (
          <ul style={{ margin: '14px 0 0', paddingLeft: 18, fontSize: 14, color: 'var(--texto-2)' }}>
            {arquivos.map((a) => (
              <li key={`${a.name}:${a.size}`}>
                {a.name} — {(a.size / 1024 / 1024).toFixed(1)} MB
                {!enviando && (
                  <button
                    type="button"
                    onClick={() =>
                      setArquivos((x) => x.filter((f) => !(f.name === a.name && f.size === a.size)))
                    }
                    style={{
                      marginLeft: 8, border: 0, background: 'none', cursor: 'pointer',
                      color: 'var(--vermelho)', font: 'inherit', fontSize: 12.5,
                    }}
                  >
                    remover
                  </button>
                )}
              </li>
            ))}
            {arquivos.length > 1 && (
              <li style={{ listStyle: 'none', marginLeft: -18, marginTop: 6, fontWeight: 600 }}>
                Total: {(totalBytes / 1024 / 1024).toFixed(1)} MB em {arquivos.length} arquivos
              </li>
            )}
          </ul>
        )}

        <div className="acoes">
          <button className="botao" onClick={enviar} disabled={!arquivos.length || enviando}>
            {enviando ? <span className="carregando" /> : 'ENVIAR E PROCESSAR'}
          </button>
        </div>

        {enviando && (
          <div style={{ marginTop: 16 }}>
            <div
              style={{
                height: 6, borderRadius: 999, background: 'var(--superficie-2)',
                border: '1px solid var(--borda)', overflow: 'hidden',
              }}
            >
              <div
                style={{
                  height: '100%', width: `${progresso}%`,
                  background: 'var(--marca)', transition: 'width .2s',
                }}
              />
            </div>
            <p style={{ fontSize: 13, color: 'var(--texto-2)', marginTop: 8 }}>
              {atual
                ? `Enviando ${atual}… ${progresso}%`
                : 'Processando no servidor. Bases grandes levam dezenas de minutos.'}
            </p>
          </div>
        )}

        {etapa >= 0 && (
          <ol style={{ marginTop: 18, paddingLeft: 20, fontSize: 14, color: 'var(--texto-2)' }}>
            {ETAPAS.map((e, i) => (
              <li key={e} style={{ color: i <= etapa ? 'var(--verde)' : 'var(--texto-3)', marginBottom: 2 }}>
                {i <= etapa ? '✓ ' : ''}{e}
              </li>
            ))}
          </ol>
        )}

        {emAndamento && (
          <div className="aviso info">
            A importação está correndo <strong>no servidor</strong>. Pode fechar
            esta página sem medo — o trabalho continua. Para conferir depois,
            abra <strong>Base TIM</strong> e olhe o histórico.
          </div>
        )}

        {erro && <div className="aviso erro">{erro}</div>}
      </div>

      {adicionado && (
        <div className="resultado" style={{ marginTop: 24 }}>
          <div className="res-faixa v-VIAVEL">
            <span className="bolha" />
            <div>
              <h3>Arquivos acrescentados</h3>
              <p>
                A base #{adicionado.baseId} continua no ar, agora maior. Não
                precisa ativar nada.
              </p>
            </div>
          </div>
          <div className="grade">
            <Item k="Registros acrescentados agora" v={adicionado.validosAgora} />
            <Item k="Com problemas nesta leva" v={adicionado.invalidosAgora} />
            <Item k="Total da base agora" v={adicionado.totalDaBase} />
            <Item k="Cidades na base" v={adicionado.municipios} />
          </div>
          <div className="rolagem">
            <table>
              <thead>
                <tr><th>Status na base inteira</th><th>Lotes</th><th>Participação</th></tr>
              </thead>
              <tbody>
                {adicionado.porStatus.map((sx) => (
                  <tr key={sx.status} style={{ cursor: 'default' }}>
                    <td><span className={`selo ${sx.status}`}>{sx.rotulo}</span></td>
                    <td>{n(sx.qtd)}</td>
                    <td>{((sx.qtd / adicionado.totalDaBase) * 100).toFixed(1)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {resultado && (
        <>
          <div className="resultado" style={{ marginTop: 24 }}>
            <div className="res-faixa v-VIAVEL">
              <span className="bolha" />
              <div>
                <h3>Importação concluída</h3>
                <p>Base #{resultado.baseId} pronta para ativação.</p>
              </div>
            </div>
            <div className="grade">
              <Item k="Registros encontrados" v={resultado.lidos} />
              <Item k="Registros válidos" v={resultado.validos} />
              <Item k="Registros com problemas" v={resultado.invalidos} />
              <Item k="Lotes duplicados" v={resultado.duplicados} />
              <Item k="Endereços com mais de um lote" v={resultado.enderecosMultiLote} />
              <Item k="Imóveis sem número" v={resultado.semNumero} />
              <Item k="Cidades" v={resultado.municipios} />
              <Item k="Data mais recente" v={resultado.dtRef ?? '—'} />
            </div>

            <div style={{ padding: 20, borderTop: '1px solid var(--borda)' }}>
              <button className="botao" onClick={ativar} disabled={ativando}>
                {ativando ? <span className="carregando" /> : 'ATIVAR ESTA BASE'}
              </button>
              <p style={{ fontSize: 13, color: 'var(--texto-3)', margin: '10px 0 0' }}>
                Até você ativar, as consultas continuam usando a base anterior.
              </p>
            </div>
          </div>

          <div className="tabela-caixa" style={{ marginTop: 24 }}>
            <header>
              Viabilidade na base importada — confira antes de ativar
            </header>
            <div className="rolagem">
              <table>
                <thead>
                  <tr><th>Status</th><th>Lotes</th><th>Participação</th></tr>
                </thead>
                <tbody>
                  {resultado.porStatus.map((s) => (
                    <tr key={s.status} style={{ cursor: 'default' }}>
                      <td><span className={`selo ${s.status}`}>{s.rotulo}</span></td>
                      <td>{n(s.qtd)}</td>
                      <td>{((s.qtd / resultado.validos) * 100).toFixed(1)}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="tabela-caixa" style={{ marginTop: 24 }}>
            <header>Arquivos processados</header>
            <div className="rolagem">
              <table>
                <thead>
                  <tr>
                    <th>Parceiro</th><th>Arquivo</th><th>Válidos</th>
                    <th>Problemas</th><th>Formato</th>
                  </tr>
                </thead>
                <tbody>
                  {resultado.arquivos.map((a) => (
                    <tr key={a.arquivo} style={{ cursor: 'default' }}>
                      <td>{a.parceiro}</td>
                      <td>{a.arquivo}</td>
                      <td>{n(a.validos)}</td>
                      <td>{n(a.invalidos)}</td>
                      <td>
                        {a.layout} · {a.encoding} · {JSON.stringify(a.delimitador)}
                        {a.colunasIgnoradas.length > 0 && (
                          <div style={{ fontSize: 12.5, color: 'var(--texto-3)' }}>
                            ignoradas: {a.colunasIgnoradas.join(', ')}
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {resultado.problemas.length > 0 && (
            <details className="tecnico card" style={{ marginTop: 24 }}>
              <summary>Ver linhas com problema ({resultado.problemas.length})</summary>
              <div style={{ paddingTop: 12, fontSize: 14, color: 'var(--texto-2)' }}>
                {resultado.problemas.slice(0, 30).map((p, i) => (
                  <div key={i}>{p.arquivo} — linha {p.linha}: {p.motivo}</div>
                ))}
              </div>
            </details>
          )}
        </>
      )}
    </>
  );
}

function Item({ k, v }: { k: string; v: number | string }) {
  return (
    <div className="item">
      <div className="k">{k}</div>
      <div className="v">{typeof v === 'number' ? n(v) : v}</div>
    </div>
  );
}
