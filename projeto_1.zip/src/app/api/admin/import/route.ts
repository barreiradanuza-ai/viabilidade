import { NextResponse } from 'next/server';
import fs from 'node:fs';
import path from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { env } from '@/lib/env';
import { exigirAdmin } from '@/lib/sessao';
import { importarBaseTim, adicionarArquivosABase } from '@/lib/importador';
import { abrirTarefa, concluirTarefa, falharTarefa, verTarefa } from '@/lib/tarefas';
import { query } from '@/lib/db';
import { registrarEvento } from '@/lib/log';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 3600;

/**
 * A base da TIM vem em vários arquivos (um por parceiro/estado), e juntos
 * eles formam UMA base. O envio é em duas etapas:
 *
 *   POST ?acao=upload&sessao=<id>&nome=<arquivo.csv>   corpo = o arquivo
 *   POST ?acao=processar&sessao=<id>                   importa tudo junto
 *
 * O arquivo vai como corpo bruto (não multipart), então é gravado em disco
 * por streaming — sem carregar 150 MB na memória do servidor e sem o CSV
 * passar pelo navegador.
 */

/** Só aceita id de sessão no formato esperado: evita subir de diretório. */
function pastaDaSessao(sessao: string | null): string {
  if (!sessao || !/^[a-z0-9-]{8,64}$/i.test(sessao)) {
    throw new Error('Sessão de upload inválida.');
  }
  return path.join(env.uploadDir, `sessao-${sessao}`);
}

/**
 * Mantém o nome que a TIM usa — inclusive o travessão de
 * "Rede TIM – Parceiro IHSsc.csv", que é de onde sai o nome do parceiro —
 * e tira só o que é perigoso num caminho de arquivo.
 */
function limparPasta(pasta: string): void {
  if (pasta) fs.rm(pasta, { recursive: true, force: true }, () => undefined);
}

function nomeSeguro(bruto: string): string {
  const base = path.basename(bruto)
    // separadores de caminho, curingas e caracteres proibidos no Windows
    .replace(/[/\\:*?"<>|]/g, '_')
    // caracteres de controle
    // eslint-disable-next-line no-control-regex
    .replace(/[\u0000-\u001f\u007f]/g, '')
    .replace(/^\.+/, '')
    .trim();
  return (base || 'base.csv').slice(0, 160);
}

export async function POST(req: Request) {
  try {
    await exigirAdmin();
  } catch {
    return NextResponse.json({ erro: 'Não autorizado.' }, { status: 401 });
  }

  const url = new URL(req.url);
  const acao = url.searchParams.get('acao') ?? 'upload';

  // Só as ações que mexem em arquivo precisam de sessão de upload.
  // "status" só consulta o banco — exigir sessão aqui quebrava o
  // acompanhamento da importação.
  let pasta = '';
  if (acao === 'upload' || acao === 'processar') {
    try {
      pasta = pastaDaSessao(url.searchParams.get('sessao'));
    } catch (e) {
      return NextResponse.json(
        { erro: e instanceof Error ? e.message : 'Sessão inválida.' },
        { status: 400 },
      );
    }
  }

  /* ---------------- envio de um arquivo ---------------- */
  if (acao === 'upload') {
    const nome = nomeSeguro(url.searchParams.get('nome') ?? 'base.csv');
    if (!/\.(csv|txt)$/i.test(nome)) {
      return NextResponse.json({ erro: 'Envie arquivos .csv.' }, { status: 400 });
    }

    const tamanho = Number(req.headers.get('content-length') ?? '0');
    if (tamanho > env.uploadMaxBytes) {
      return NextResponse.json(
        {
          erro: `"${nome}" é maior que o limite de ${Math.round(
            env.uploadMaxBytes / 1024 / 1024,
          )} MB.`,
        },
        { status: 413 },
      );
    }
    if (!req.body) {
      return NextResponse.json({ erro: `"${nome}" chegou vazio.` }, { status: 400 });
    }

    fs.mkdirSync(pasta, { recursive: true, mode: 0o700 });
    const destino = path.join(pasta, nome);
    try {
      await pipeline(
        Readable.fromWeb(req.body as never),
        fs.createWriteStream(destino, { mode: 0o600 }),
      );
      return NextResponse.json({ ok: true, nome, bytes: fs.statSync(destino).size });
    } catch {
      fs.rm(destino, { force: true }, () => undefined);
      return NextResponse.json({ erro: `Falha ao receber "${nome}".` }, { status: 500 });
    }
  }

  /* ---------------- processamento do conjunto ---------------- */
  if (acao === 'processar') {
    if (!fs.existsSync(pasta)) {
      return NextResponse.json({ erro: 'Nenhum arquivo foi enviado.' }, { status: 400 });
    }
    const arquivos = fs
      .readdirSync(pasta)
      .filter((f) => /\.(csv|txt)$/i.test(f))
      .sort()
      .map((f) => ({ caminho: path.join(pasta, f), nome: f }));

    if (!arquivos.length) {
      return NextResponse.json({ erro: 'Nenhum arquivo foi enviado.' }, { status: 400 });
    }

    /* ---------- acrescentar a uma base que já existe ---------- */
    const destino = url.searchParams.get('destino') ?? 'nova';
    if (destino !== 'nova') {
      const baseId = Number(destino);
      if (!Number.isInteger(baseId) || baseId <= 0) {
        limparPasta(pasta);
        return NextResponse.json({ erro: 'Base de destino inválida.' }, { status: 400 });
      }

      const tarefaId = `add-${baseId}-${Date.now()}`;
      abrirTarefa(tarefaId);

      adicionarArquivosABase(baseId, { arquivos })
        .then((r) => {
          concluirTarefa(tarefaId, r);
          registrarEvento(
            'INFO', 'importacao',
            `${r.validosAgora} registros acrescentados à base #${baseId}`,
            { arquivos: arquivos.map((a) => a.nome), total: r.totalDaBase },
          );
        })
        .catch((e) => {
          const msg = e instanceof Error ? e.message : 'Falha ao acrescentar.';
          falharTarefa(tarefaId, msg);
          registrarEvento('ERRO', 'importacao', msg, {
            arquivos: arquivos.map((a) => a.nome), baseId,
          });
        })
        .finally(() => limparPasta(pasta));

      return NextResponse.json(
        { ok: true, emAndamento: true, tarefaId, baseId },
        { status: 202 },
      );
    }

    /*
     * A importação de gigabytes leva dezenas de minutos, e o roteador da
     * hospedagem corta requisições muito longas ("upstream error"). Então
     * não seguramos a requisição: validamos os cabeçalhos (rápido), criamos
     * a versão da base, respondemos na hora com o número dela, e o trabalho
     * pesado continua no servidor. A tela acompanha pelo status.
     */
    const limpar = () => limparPasta(pasta);

    let baseCriada: (id: number) => void = () => undefined;
    const idDaBase = new Promise<number>((res) => {
      baseCriada = res;
    });

    const trabalho = importarBaseTim({
      arquivos,
      ativar: false,
      aoCriarBase: (id) => baseCriada(id),
    });

    // Ou a base é criada (e aí respondemos), ou falha antes disso — o que
    // só acontece na validação de cabeçalho, que é rápida e vale devolver
    // na hora, com a mensagem exata do arquivo problemático.
    const corrida = await Promise.race([
      idDaBase.then((id) => ({ tipo: 'iniciada' as const, id })),
      trabalho.then(
        (r) => ({ tipo: 'terminou' as const, r }),
        (e) => ({ tipo: 'erro' as const, e }),
      ),
    ]);

    if (corrida.tipo === 'erro') {
      limpar();
      const msg =
        corrida.e instanceof Error
          ? corrida.e.message
          : 'Falha ao processar os arquivos.';
      registrarEvento('ERRO', 'importacao', msg, {
        arquivos: arquivos.map((a) => a.nome),
      });
      return NextResponse.json(
        { erro: msg, aviso: 'A base anterior continua ativa.' },
        { status: 400 },
      );
    }

    if (corrida.tipo === 'terminou') {
      limpar();
      registrarEvento('INFO', 'importacao', `Base #${corrida.r.baseId} processada`, {
        arquivos: arquivos.map((a) => a.nome),
        validos: corrida.r.validos,
      });
      return NextResponse.json({ ok: true, baseId: corrida.r.baseId, resultado: corrida.r });
    }

    // Segue correndo. O catch aqui evita "unhandled rejection" derrubar o
    // processo — o erro já foi gravado em base_versao pelo próprio importador.
    trabalho
      .then((r) =>
        registrarEvento('INFO', 'importacao', `Base #${r.baseId} processada`, {
          arquivos: arquivos.map((a) => a.nome),
          validos: r.validos,
        }),
      )
      .catch((e) =>
        registrarEvento(
          'ERRO', 'importacao',
          e instanceof Error ? e.message : 'Falha na importação',
          { arquivos: arquivos.map((a) => a.nome) },
        ),
      )
      .finally(limpar);

    return NextResponse.json(
      { ok: true, emAndamento: true, baseId: corrida.id },
      { status: 202 },
    );
  }

  /* ---------------- acompanhamento ---------------- */
  if (acao === 'status') {
    const tarefaId = url.searchParams.get('tarefaId');
    if (tarefaId) {
      const t = verTarefa(tarefaId);
      if (!t) {
        // Servidor reiniciou: a transação caiu e a base ficou intacta.
        return NextResponse.json({
          ok: true, estado: 'ERRO',
          erro: 'O servidor reiniciou durante a operação. A base não foi alterada — tente de novo.',
        });
      }
      return NextResponse.json({ ok: true, ...t });
    }

    const baseId = Number(url.searchParams.get('baseId'));
    if (!Number.isInteger(baseId) || baseId <= 0) {
      return NextResponse.json({ erro: 'Base inválida.' }, { status: 400 });
    }
    const r = await query<{
      status: string; registros_lidos: string; registros_validos: string;
      registros_invalidos: string; registros_duplicados: string;
      erro_mensagem: string | null; dt_ref: string | null; relatorio: unknown;
    }>(
      `SELECT status, registros_lidos, registros_validos, registros_invalidos,
              registros_duplicados, erro_mensagem, dt_ref, relatorio
         FROM base_versao WHERE id = $1`,
      [baseId],
    );
    if (!r.length) {
      return NextResponse.json({ erro: 'Base não encontrada.' }, { status: 404 });
    }
    return NextResponse.json({ ok: true, baseId, ...r[0] });
  }

  return NextResponse.json({ erro: 'Ação desconhecida.' }, { status: 400 });
}
