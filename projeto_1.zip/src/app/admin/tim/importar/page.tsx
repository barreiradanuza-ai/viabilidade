import ImportarBase from '@/components/ImportarBase';
import { query } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function PaginaImportar() {
  // Base que já está no ar: é para ela que dá para acrescentar arquivos.
  const ativa = await query<{ id: string; registros_validos: string; arquivos: string[] | null }>(
    `SELECT id, registros_validos, arquivos FROM base_versao
      WHERE operadora = 'TIM' AND status = 'ATIVA' LIMIT 1`,
  ).catch(() => []);

  const base = ativa.length
    ? {
        id: Number(ativa[0].id),
        registros: Number(ativa[0].registros_validos),
        arquivos: ativa[0].arquivos ?? [],
      }
    : null;

  return (
    <>
      <h1 className="titulo">Importar base TIM</h1>
      <p className="subtitulo">
        Você pode criar uma base nova do zero ou acrescentar arquivos à base que
        já está no ar — útil quando a entrega vem em muitos arquivos e não dá
        para mandar todos de uma vez.
      </p>
      <ImportarBase baseAtiva={base} />
    </>
  );
}
